---
title: "埃塞俄比亚国家投资数据库 - 导航"
---

# 🇪🇹 埃塞俄比亚国家投资数据库

> 完整知识图谱，78篇深度文档，覆盖宏观底座→产业纵深→投资决策→工具箱全链路

## 🎯 投资决策区

### 一页纸决策
- [[one-page-decision|一页纸决策]]

### 风险与红旗
- [[risk-scenarios|风险场景]]
- [[red-flags|红旗清单]]
- [[policy-window|政策窗口]]

### 优先级矩阵
- [[priority-matrix|优先级矩阵]]

### 行业速查卡
- [[mining|矿产]] · [[coffee|咖啡]] · [[agriculture|农业]]
- [[real-estate|房地产]] · [[building-materials|建材]] · [[cement|水泥]]
- [[crypto-mining|加密算力]] · [[renewable-energy|可再生能源]] · [[power-export|电力出口]]
- [[fintech|金融科技]] · [[telecom|电信]] · [[digital-economy|数字经济]]
- [[textile|纺织]] · [[agro-processing|农产品加工]] · [[consumer-goods|消费品]]
- [[automotive|汽车]] · [[ev|新能源车]] · [[logistics|物流]]

---

## 🔍 底层逻辑区

### 为何存在
- [[great-power-game|大国博弈]]
- [[climate-killer|气候杀手]]

### 权力结构
- [[power-map|权力地图]]
- [[article39|宪法第39条]]
- [[diaspora-control|侨民控制]]

### 资金暗流
- [[khat-shadow-economy|恰特草影子经济]]
- [[remittance|侨汇]]
- [[money-printer|印钞机]]

### 社会安全网
- [[equb-iddir|埃库布与伊迪尔]]
- [[religion-economy|宗教经济]]

### 结构性变动
- [[fx-liberalization|外汇自由化]]
- [[zero-tariff|零关税]]
- [[china-downgrade|中国降级]]
- [[red-sea-crisis|红海危机]]
- [[defense-debt-geostrategy|国防经济与主权债务重组]]

### 数据面板
- [[macroeconomy|宏观经济]]
- [[population-labor|人口与劳动力]]
- [[infrastructure|基础设施]]
- [[diplomacy|外交关系]]
- [[geography-climate|地理与气候]]
- [[political-structure|政治结构]]
- [[ethnicity-religion|民族与宗教]]

---

## 🏭 产业纵深区

### 底座产业
- [[mining|矿产]] · [[agriculture|农业]] · [[power-energy|电力与能源]]

### 动脉产业
- [[railway-highway|铁路与公路]] · [[logistics-customs|通关与物流]] · [[ports|港口]]

### 金融产业
- [[banking|银行]] · [[capital-market|资本市场]] · [[fx-system|外汇管制]]

### 内需产业
- [[real-estate|房地产]] · [[building-materials|建材]] · [[digital-economy|数字经济]]
- [[agro-processing|农产品加工]] · [[consumer-goods|消费品]] · [[ev|新能源车]]

### 套利产业
- [[crypto-mining|加密算力]] · [[power-export|电力出口]] · [[zero-carbon|零碳]]

---

## 🧰 工具箱

### 城市档案
- [[addis-ababa|亚的斯亚贝巴]] · [[dire-dawa|德雷达瓦]] · [[bahir-dar|巴赫达尔]] · [[adama|阿达玛]]

### 企业与项目
- [[chinese-companies|中资企业]] · [[industrial-parks|工业园]] · [[top-companies|头部企业]] · [[key-projects|关键项目]]

### 法律法规
- [[investment-access|投资准入]] · [[tax-guide|税务指南]] · [[land-acquisition|土地获取]]
- [[fx-control|外汇管制法规]] · [[labor-law|劳动法]] · [[dispute-resolution|争端解决]]

### 数据面板
- [[macro-indicators|宏观指标]] · [[trade-data|贸易数据]] · [[cost-factors|成本因素]] · [[data-sources|数据来源]]
